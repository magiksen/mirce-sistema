-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.17-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla postesdb.muestras
CREATE TABLE IF NOT EXISTS `muestras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_institucion` varchar(100) DEFAULT NULL,
  `pago` varchar(100) DEFAULT NULL,
  `dolares` float DEFAULT 0,
  `bolivares` float DEFAULT 0,
  `nombre_paciente` varchar(100) DEFAULT NULL,
  `ci_paciente` varchar(100) DEFAULT NULL,
  `codigo` varchar(100) DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `bloque` varchar(100) DEFAULT NULL,
  `lamina` varchar(100) DEFAULT NULL,
  `impresa` varchar(100) DEFAULT NULL,
  `fecha` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla postesdb.muestras: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `muestras` DISABLE KEYS */;
INSERT INTO `muestras` (`id`, `nombre_institucion`, `pago`, `dolares`, `bolivares`, `nombre_paciente`, `ci_paciente`, `codigo`, `tipo`, `bloque`, `lamina`, `impresa`, `fecha`) VALUES
	(1, 'Clinica 1', 'Sin pago', 0, 0, 'Juana', '15123123', '2000-21', 'Citologia', NULL, NULL, 'Si', '19/06/2021');
INSERT INTO `muestras` (`id`, `nombre_institucion`, `pago`, `dolares`, `bolivares`, `nombre_paciente`, `ci_paciente`, `codigo`, `tipo`, `bloque`, `lamina`, `impresa`, `fecha`) VALUES
	(2, 'Tony Stark', 'Pago', 10, 1000000, 'Bruce ', '14122122', '150-21', 'Biopsia', '1-21', '1-21', 'No', '20/06/2021');
INSERT INTO `muestras` (`id`, `nombre_institucion`, `pago`, `dolares`, `bolivares`, `nombre_paciente`, `ci_paciente`, `codigo`, `tipo`, `bloque`, `lamina`, `impresa`, `fecha`) VALUES
	(3, 'Tekesan', 'Sin pago', 0, 0, 'Peter Parker', '20123123', '1000-21', 'Citologia', NULL, NULL, 'no', '20/06/2021');
INSERT INTO `muestras` (`id`, `nombre_institucion`, `pago`, `dolares`, `bolivares`, `nombre_paciente`, `ci_paciente`, `codigo`, `tipo`, `bloque`, `lamina`, `impresa`, `fecha`) VALUES
	(4, 'Clinica 2', 'Con pago', 80, 0, 'Corey Hart', '9345678', '1001-21', 'Autopsias', NULL, NULL, 'no', '20/06/2021');
/*!40000 ALTER TABLE `muestras` ENABLE KEYS */;

-- Volcando estructura para tabla postesdb.opciones
CREATE TABLE IF NOT EXISTS `opciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `precio` float NOT NULL DEFAULT 0,
  `iva` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla postesdb.opciones: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `opciones` DISABLE KEYS */;
INSERT INTO `opciones` (`id`, `precio`, `iva`) VALUES
	(1, 10000, 12);
/*!40000 ALTER TABLE `opciones` ENABLE KEYS */;

-- Volcando estructura para tabla postesdb.postes
CREATE TABLE IF NOT EXISTS `postes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(100) DEFAULT NULL,
  `peso_t1` float DEFAULT 0,
  `peso_t2` float DEFAULT 0,
  `peso_t3` float DEFAULT 0,
  `long_t1` float DEFAULT 0,
  `long_t2` float DEFAULT 0,
  `long_t3` float DEFAULT 0,
  `camisa` float DEFAULT 0,
  `tapa` float DEFAULT 0,
  `junta1` float DEFAULT NULL,
  `junta2` float DEFAULT NULL,
  `junta3` float DEFAULT NULL,
  `peso_total` float DEFAULT 0,
  `long_total` float DEFAULT 0,
  `kg_mts` float DEFAULT 0,
  `precio_venta` float DEFAULT NULL,
  `precio_iva` float DEFAULT NULL,
  `precio_final` float DEFAULT NULL,
  `n_usuario` varchar(100) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla postesdb.postes: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `postes` DISABLE KEYS */;
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(1, 'PCI1701A', 50, 100, 150, 25, 40, 60, 10, 5, 0, 0, 0, 14265, 125, 114.12, 1141200, 136944, 1278140, 'samircastro', '2017-02-15 11:46:33');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(2, 'PCI1710A', 200, 120, 170, 10, 20, 15, 30, 10, 0, 0, 0, 6990, 45, 155.33, 1553300, 186396, 1739700, 'samircastro', '2017-02-15 11:46:33');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(3, 'PCI1701C', 10, 15, 13, 20, 15, 12, 10, 5, 0, 0, 0, 596, 47, 12.68, 126800, 15216, 142016, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(5, 'PCI1620B', 10, 9, 10, 7, 6, 8, 4, 1, 0.4, 0.4, 0, 209, 21.8, 9.59, 95900, 11508, 107408, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(6, 'PCI1620C', 9.25, 6.52, 7.25, 11.1, 10.2, 8.1, 4.25, 1.25, 0, 0.4, 0.4, 233.4, 30.2, 7.73, 77300, 9276, 86576, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(7, 'PCI1620A', 10.2, 11.3, 8.9, 6.25, 7.3, 5.45, 5.56, 1.15, 0.4, 0.4, 0, 201.46, 19.8, 10.17, 101700, 12204, 113904, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(8, 'PCI1821A', 12, 10, 15, 5, 6, 8, 10, 1, 0, 0.4, 0.4, 251, 19.8, 12.68, 126800, 15216, 142016, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(9, 'PCI1821B', 4.35, 5.25, 6.35, 6.2, 6.25, 7.5, 6, 1.25, 0.4, 0.4, 0, 114.66, 20.75, 5.53, 55300, 6636, 61936, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(10, 'PCI1825A', 16.5, 12.35, 14.9, 8.4, 8.5, 9.6, 10.25, 2, 0, 0.4, 0.4, 398.87, 27.3, 14.61, 146100, 17532, 163632, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(12, 'PCI1825B', 10, 15, 20, 5, 5, 5, 2, 1, 0, 0.4, 0.4, 228, 15.8, 14.43, 144300, 17316, 161616, 'samircastro', '2017-02-15 11:46:34');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(13, 'PCI1720D', 8, 10, 12, 4.3, 5.3, 6.3, 2.5, 1.25, 0, 0.4, 0.4, 166.75, 16.7, 9.99, 99900, 11988, 111888, 'samircastro', '2017-02-15 11:46:35');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(14, 'PCI1721D', 5, 7, 9, 3, 5, 7, 2, 1, 0.4, 0.4, 0, 116, 15.8, 7.34, 73400, 8808, 82208, 'samircastro', '2017-02-15 11:46:35');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(15, 'PCI1621A', 3, 5, 4, 5, 6, 4, 2, 1, 0, 0.4, 0.4, 64, 15.8, 4.05, 40500, 4860, 45360, 'samircastro', '2017-02-15 11:46:35');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(17, 'PCI2021A', 4.3, 3.6, 3.6, 3, 2, 2, 2, 1, 0.4, 0.4, 0, 30.3, 7.8, 3.88, 38800, 4656, 43456, 'samircastro', '2017-02-15 11:46:35');
INSERT INTO `postes` (`id`, `codigo`, `peso_t1`, `peso_t2`, `peso_t3`, `long_t1`, `long_t2`, `long_t3`, `camisa`, `tapa`, `junta1`, `junta2`, `junta3`, `peso_total`, `long_total`, `kg_mts`, `precio_venta`, `precio_iva`, `precio_final`, `n_usuario`, `fecha`) VALUES
	(18, 'PCI2021B', 5, 5.6, 6, 3.4, 4, 4, 2, 1.25, 0.4, 0.4, 0, 66.65, 12.2, 5.46, 54600, 6552, 61152, 'samircastro', '2017-02-15 11:46:35');
/*!40000 ALTER TABLE `postes` ENABLE KEYS */;

-- Volcando estructura para tabla postesdb.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(100) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `ci` int(11) NOT NULL,
  `departamento` varchar(50) NOT NULL,
  `pass` varchar(512) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`usuario`),
  UNIQUE KEY `ci` (`ci`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla postesdb.usuarios: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`, `usuario`, `nombre`, `apellido`, `ci`, `departamento`, `pass`, `tipo`) VALUES
	(3, 'magiksen', 'Samuel', 'Escobar', 5680415, 'Informatica', '92f39f7f2a869838cd5085e6f17fc82109bcf98cd62a47cbc379e38de80bbc0213a23cee6e4a13de6caae0add8a390272d6f0883c274320b1ff60dbcfc6dd750', 'super');
INSERT INTO `usuarios` (`id`, `usuario`, `nombre`, `apellido`, `ci`, `departamento`, `pass`, `tipo`) VALUES
	(8, 'mircelab', 'Mirce', 'Lopez', 12540820, 'Doctora', '92f39f7f2a869838cd5085e6f17fc82109bcf98cd62a47cbc379e38de80bbc0213a23cee6e4a13de6caae0add8a390272d6f0883c274320b1ff60dbcfc6dd750', 'admin');
INSERT INTO `usuarios` (`id`, `usuario`, `nombre`, `apellido`, `ci`, `departamento`, `pass`, `tipo`) VALUES
	(10, 'sam_esco', 'Samuel', 'Escobar', 20192274, 'Informatica', '92f39f7f2a869838cd5085e6f17fc82109bcf98cd62a47cbc379e38de80bbc0213a23cee6e4a13de6caae0add8a390272d6f0883c274320b1ff60dbcfc6dd750', 'user');
INSERT INTO `usuarios` (`id`, `usuario`, `nombre`, `apellido`, `ci`, `departamento`, `pass`, `tipo`) VALUES
	(13, 'testing', 'Usuario1', 'Usuerio test', 12121121, 'No se', '92f39f7f2a869838cd5085e6f17fc82109bcf98cd62a47cbc379e38de80bbc0213a23cee6e4a13de6caae0add8a390272d6f0883c274320b1ff60dbcfc6dd750', 'user');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
